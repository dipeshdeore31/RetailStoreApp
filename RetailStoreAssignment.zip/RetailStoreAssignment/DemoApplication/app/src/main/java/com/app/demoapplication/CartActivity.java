package com.app.demoapplication;

import android.app.Activity;
import android.content.Context;
import android.database.sqlite.SQLiteException;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.app.adapters.CartListAdapter;
import com.app.adapters.StoreProductsAdapter;
import com.app.dao.DbHelper;
import com.app.dao.RetailStoreDao;
import com.app.models.ItemDataModel;
import com.app.utilities.AbstractActivity;
import com.app.utilities.UiUtils;

import java.util.ArrayList;

public class CartActivity extends AbstractActivity {

    private TextView txtTitle;
    private ListView lvCartItems;
    private CartListAdapter cartListAdapter;
    private Activity activity;
    private TextView txtTotalPrice;
    private ArrayList<ItemDataModel> itemsList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);
        activity = this;
        initUI();
        setFonts();
        setListener();
        setCustomData();
    }


    private void initUI() {
        txtTitle = (TextView) findViewById(R.id.txt_title);
        txtTitle.setText(getResources().getString(R.string.yourcart));
        lvCartItems = (ListView) findViewById(R.id.lv_cartlist);
        txtTotalPrice = (TextView) findViewById(R.id.txt_total_price);
    }

    private void setCustomData() {

        itemsList = new ArrayList<>();
        try {

            DbHelper.init(activity);

            RetailStoreDao retailStoreDao = new RetailStoreDao();

            itemsList = retailStoreDao.getCartsData();

        } catch (SQLiteException sqliteException) {

        } finally {

            DbHelper.sharedDbHelper().closeDatabase();

        }

        for (int i = 0; i < itemsList.size(); i++) {

            if (itemsList.get(i).getProductCategory().equalsIgnoreCase("Electronics")) {
                if (itemsList.get(i).getItemId().equalsIgnoreCase("1")) {
                    itemsList.get(i).setResourceId(R.drawable.oven);
                } else if (itemsList.get(i).getItemId().equalsIgnoreCase("2")) {
                    itemsList.get(i).setResourceId(R.drawable.tv);
                } else {
                    itemsList.get(i).setResourceId(R.drawable.vaccum_cleaner);
                }
            } else {
                if (itemsList.get(i).getItemId().equalsIgnoreCase("4")) {
                    itemsList.get(i).setResourceId(R.drawable.table);
                } else if (itemsList.get(i).getItemId().equalsIgnoreCase("5")) {
                    itemsList.get(i).setResourceId(R.drawable.chair);
                } else {
                    itemsList.get(i).setResourceId(R.drawable.almirah);
                }
            }

        }

        cartListAdapter = new CartListAdapter(activity, itemsList, new DeleteItemsFromListDeligateResult(), regularFont);
        lvCartItems.setAdapter(cartListAdapter);

        int total = 0;
        for (int i = 0; i < itemsList.size(); i++) {
            total = total + Integer.parseInt(itemsList.get(i).getPrice().replace("₹ ", ""));
        }
        txtTotalPrice.setText("Total Price : ₹ " + total);
    }

    private void setFonts() {
        txtTitle.setTypeface(regularFont);
        txtTotalPrice.setTypeface(regularFont);
    }

    private void setListener() {
        lvCartItems.setOnItemClickListener(new CartItemListener());
    }

    private class CartItemListener implements AdapterView.OnItemClickListener {

        @Override
        public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {

            Bundle bundle = new Bundle();
            bundle.putString(Product_ID, itemsList.get(position).getItemId());
            bundle.putInt(Image_ID, itemsList.get(position).getResourceId());
            UiUtils.goToActivity(activity, ProductDetailsActivity.class, bundle);

        }
    }

    private class DeleteItemsFromListDeligateResult implements CartListAdapter.DeleteRecordDeligate {
        @Override
        public void deleteItemfromCart(String productId) {

//            TODO Set cart_status to blank in Database

            try {

                DbHelper.init(activity);

                RetailStoreDao retailStoreDao = new RetailStoreDao();

                retailStoreDao.updateCartStatus(productId, "");

            } catch (SQLiteException sqliteException) {

            } finally {

                DbHelper.sharedDbHelper().closeDatabase();

            }

            Toast.makeText(activity,getResources().getString(R.string.item_removed),Toast.LENGTH_SHORT).show();

        }
    }

}
