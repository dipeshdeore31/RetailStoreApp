package com.app.utilities;

public interface AppConstants {

    public String Roboto_Condense_Regular = "RobotoCondensedRegular.ttf";
    public String Roboto_Condense_Bold = "RobotoCondensedBold.ttf";
    public String Product_ID = "Product_ID";
    public String Image_ID = "Image_ID";

}
