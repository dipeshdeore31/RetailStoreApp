package com.app.demoapplication;

import android.app.Activity;
import android.content.Context;
import android.database.sqlite.SQLiteException;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.TextView;

import com.app.adapters.StoreProductsAdapter;
import com.app.dao.CreateOrUpgradeDbTask;
import com.app.dao.DbHelper;
import com.app.dao.RetailStoreDao;
import com.app.models.ItemDataModel;
import com.app.utilities.AbstractActivity;
import com.app.utilities.UiUtils;

import java.util.ArrayList;

public class StoreActivity extends AbstractActivity {

    private TextView txtTitle;
    private ImageButton ibtnCart;
    private GridView gridItemsList;
    private StoreProductsAdapter storeProductsAdapter;
    private Activity activity;
    private EditText etSearch;
    private ArrayList<ItemDataModel> itemsList;
//  Show Electronics items by default
    private String category = "Electronics";
    private Button btnElectronics;
    private Button btnFurniture;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_store);
        activity = this;
        new CreateOrUpgradeDbTask(activity.getApplicationContext()).execute();

        initUI();
        setFonts();
        setListener();
        setCustomData();

    }


    private void initUI() {

        txtTitle = (TextView) findViewById(R.id.txt_title);
        txtTitle.setText(getResources().getString(R.string.products));
        ibtnCart = (ImageButton) findViewById(R.id.ibtn_cart);
        gridItemsList = (GridView) findViewById(R.id.grid_view_items);
        etSearch = (EditText) findViewById(R.id.et_search);
        btnElectronics = (Button) findViewById(R.id.btn_electronics);
        btnFurniture = (Button) findViewById(R.id.btn_furniture);

    }

    private void setCustomData() {

//        Get Products data from the database

        itemsList = new ArrayList<>();

        try {

            DbHelper.init(activity);

            RetailStoreDao retailStoreDao = new RetailStoreDao();

            itemsList = retailStoreDao.getProductData(category);

        } catch (SQLiteException sqliteException) {

        } finally {

            DbHelper.sharedDbHelper().closeDatabase();

        }

//        Set image Resource Ids in the Arraylist models
        for (int i = 0; i < itemsList.size(); i++) {

            if (itemsList.get(i).getProductCategory().equalsIgnoreCase("Electronics")) {
                if (i == 0) {
                    itemsList.get(i).setResourceId(R.drawable.oven);
                } else if (i == 1) {
                    itemsList.get(i).setResourceId(R.drawable.tv);
                } else if (i == 2) {
                    itemsList.get(i).setResourceId(R.drawable.vaccum_cleaner);
                }
            } else {
                if (i == 0) {
                    itemsList.get(i).setResourceId(R.drawable.table);
                } else if (i == 1) {
                    itemsList.get(i).setResourceId(R.drawable.chair);
                } else if (i == 2) {
                    itemsList.get(i).setResourceId(R.drawable.almirah);
                }
            }

        }

        storeProductsAdapter = new StoreProductsAdapter(activity, itemsList);
        gridItemsList.setAdapter(storeProductsAdapter);
    }

    private void setFonts() {
        txtTitle.setTypeface(regularFont);
        etSearch.setTypeface(regularFont);
        btnFurniture.setTypeface(regularFont);
        btnElectronics.setTypeface(regularFont);
    }

    private void setListener() {

        etSearch.addTextChangedListener(new SearchTextWatcher());

        gridItemsList.setOnItemClickListener(new ProductClickListener());

        ibtnCart.setOnClickListener(new CartButtonListener());

//        Change products on Tab(Electronics/Furniture) Clicks

        btnElectronics.setOnClickListener(new ElectronicBtnListener());

        btnFurniture.setOnClickListener(new FurnitureBtnListener());

    }

    private class ElectronicBtnListener implements View.OnClickListener {

        @Override
        public void onClick(View view) {

            category = "Electronics";
            setCustomData();
        }
    }

    private class FurnitureBtnListener implements View.OnClickListener {

        @Override
        public void onClick(View view) {

            category = "Furniture";
            setCustomData();

        }
    }

    private class ProductClickListener implements AdapterView.OnItemClickListener {

        @Override
        public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
//          Navigate to Product details n pass productId, ImageId
            Bundle bundle = new Bundle();
            bundle.putString(Product_ID, itemsList.get(position).getItemId());
            bundle.putInt(Image_ID, itemsList.get(position).getResourceId());
            UiUtils.goToActivity(activity, ProductDetailsActivity.class, bundle);

        }
    }

    private class CartButtonListener implements View.OnClickListener {

        @Override
        public void onClick(View view) {

            UiUtils.goToActivity(activity, CartActivity.class, null);

        }
    }

//   Filter products list depending on search text
    private class SearchTextWatcher implements TextWatcher {

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {

            if (storeProductsAdapter != null) {
                storeProductsAdapter.getFilter().filter(s);
            }

        }

        @Override
        public void beforeTextChanged(CharSequence s, int start, int count,
                                      int after) {

        }

        @Override
        public void afterTextChanged(Editable s) {

        }
    }


    // To Hide Keyboard on outside Touch
    @Override
    public boolean dispatchTouchEvent(MotionEvent event) {
        View view = getCurrentFocus();
        boolean ret = super.dispatchTouchEvent(event);

        if (view instanceof EditText) {
            View w = getCurrentFocus();
            int scrcoords[] = new int[2];
            w.getLocationOnScreen(scrcoords);
            float x = event.getRawX() + w.getLeft() - scrcoords[0];
            float y = event.getRawY() + w.getTop() - scrcoords[1];

            if (event.getAction() == MotionEvent.ACTION_UP && (x < w.getLeft() || x >= w.getRight() || y < w.getTop() || y > w.getBottom())) {
                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.hideSoftInputFromWindow(getWindow().getCurrentFocus().getWindowToken(), 0);
            }
        }
        return ret;
    }

}
