package com.app.dao;

import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class GetDB {

    public SQLiteDatabase db;
    Cursor cursor;
    public SQLiteOpenHelper mDBHelper;

    public void openDb() throws SQLException {
        try {
            db = mDBHelper.getWritableDatabase();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public Cursor selectQuery(String sql, String[] args) {
        try {
            cursor = db.rawQuery(sql, args);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return cursor;
    }

    public void Query(String sql, Object[] bindArgs) {
        try {
            db.execSQL(sql, bindArgs);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void delete(String tableName, String whereClause, String[] whereArgs) {
        try {

            db.delete(tableName, whereClause, whereArgs);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void closeCursor() {
        if (cursor != null) {
            cursor.close();
        }
    }

    public void closeDB() {
        if (db != null && db.isOpen()) {
            db.close();
            mDBHelper.close();
        }
    }
}
