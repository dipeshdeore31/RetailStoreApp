package com.app.utilities;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

public class AbstractActivity extends Activity implements ActivityHelper {

    private ActivityHelper ah = new ActivityHelperImpl(this);

    public Typeface regularFont;
    public Typeface boldFont;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        regularFont = createTypeFace(Roboto_Condense_Regular);

    }

    @Override
    public void hideKeyboard(View view) {

        ah.hideKeyboard(view);

    }

    /* For creating required typeface */
    @Override
    public Typeface createTypeFace(String fontName) {

        return ah.createTypeFace(fontName);

    }

    /* Switch to some activity with bundle values and kill current activity */
    @Override
    public void switchToActivity(Activity current, Class<? extends Activity> otherActivityClass, Bundle extras) {

        ah.switchToActivity(current, otherActivityClass, extras);

    }

    /* Go to some activity with bundle values */
    @Override
    public void goToActivity(Activity current, Class<? extends Activity> otherActivityClass, Bundle extras) {

        ah.goToActivity(current, otherActivityClass, extras);
    }

}
