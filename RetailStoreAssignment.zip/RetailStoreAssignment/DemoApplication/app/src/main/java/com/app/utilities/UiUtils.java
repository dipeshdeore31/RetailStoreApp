package com.app.utilities;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;

public class UiUtils {

    public static void switchToActivity(Activity current, Class<? extends Activity> otherActivityClass, Bundle extras) {
        Intent intent = new Intent(current, otherActivityClass);
        if (extras != null) {
            intent.putExtras(extras);
        }
        current.startActivity(intent);
        current.finish();
    }

    public static void goToActivity(Activity current, Class<? extends Activity> otherActivityClass, Bundle extras) {
        Intent intent = new Intent(current, otherActivityClass);
        if (extras != null) {
            intent.putExtras(extras);
        }
        current.startActivity(intent);
    }

    public static Typeface createTypeFace(Context context, String fontName) {
        Typeface tf = Typeface.createFromAsset(context.getApplicationContext().getAssets(), fontName);
        return tf;
    }


}
