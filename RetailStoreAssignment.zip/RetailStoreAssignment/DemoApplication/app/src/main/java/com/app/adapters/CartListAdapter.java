package com.app.adapters;

import android.content.Context;
import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.app.demoapplication.R;
import com.app.models.ItemDataModel;

import java.util.ArrayList;

public class CartListAdapter extends BaseAdapter {

    private Context context;
    private ArrayList<ItemDataModel> cartList;
    private LayoutInflater inflater;
    private DeleteRecordDeligate delegate;
    private Typeface font;

    public CartListAdapter(Context context, ArrayList<ItemDataModel> objects, DeleteRecordDeligate delegate, Typeface font) {
        super();
        this.context = context;
        this.cartList = objects;
        this.delegate = delegate;
        this.font = font;

        this.inflater = (LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);

    }


    @Override
    public int getCount() {
        return cartList.size();

    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        if (convertView == null) {
            holder = new ViewHolder();
            convertView = inflater.inflate(R.layout.item_cart_list, null);

            holder.txtProductInfo = (TextView) convertView.findViewById(R.id.txt_item_name_price);

            holder.imgProduct = (ImageView) convertView.findViewById(R.id.img_photo);

            holder.imgDeleteProduct = (ImageView) convertView.findViewById(R.id.img_cancel);
            convertView.setTag(holder);
        } else
            holder = (ViewHolder) convertView.getTag();


        holder.txtProductInfo.setText(cartList.get(position).getItemName() + " : " + cartList.get(position).getPrice());
        holder.txtProductInfo.setTypeface(font);

        holder.imgProduct.setImageResource(cartList.get(position).getResourceId());

        holder.imgDeleteProduct.setTag(position);
        holder.imgDeleteProduct.setOnClickListener(new RemoveContactFromSelectedListOnClickListener());

        return convertView;
    }

    public interface DeleteRecordDeligate {
        public void deleteItemfromCart(String message);
    }


    public static class ViewHolder {
        TextView txtProductInfo;
        ImageView imgProduct;
        ImageView imgDeleteProduct;
    }

    public class RemoveContactFromSelectedListOnClickListener implements View.OnClickListener {

        @Override
        public void onClick(View v) {

            int position = Integer.parseInt(v.getTag().toString());

            delegate.deleteItemfromCart(cartList.get(position).getItemId());

            cartList.remove(position);

            notifyDataSetChanged();

        }
    }

}

