package com.app.dao;

import android.content.ContentValues;
import android.database.Cursor;

import com.app.models.ItemDataModel;
import com.app.utilities.Logger;

import java.util.ArrayList;
import java.util.List;

public class RetailStoreDao extends AbstractDao {

    private static final String TABLE_PRODUCT_DATA = "products";
    private static final String PRODUCT_ID = "product_id";
    private static final String PRODUCT_NAME = "product_name";
    private static final String PRODUCT_PRICE = "product_price";
    private static final String PRODUCT_DETAILS = "product_details";
    private static final String CART_STATUS = "cart_status";
    private static final String PRODUCT_CATEGORY = "productCategory";

    public RetailStoreDao() {
        this.mDbHelper = DbHelper.sharedDbHelper();
        openDatabase();
    }

    public int updateCartStatus(String productId,String status) {
        ContentValues value = new ContentValues();
        value.put(CART_STATUS, status);
        Logger.debug("update query - " + PRODUCT_ID + " = '" + productId + "'");
        return this.db.update(TABLE_PRODUCT_DATA, value, PRODUCT_ID + " = \"" + productId + "\"", null);
    }

    public ArrayList<ItemDataModel> getProductData(String category) {

        ArrayList<ItemDataModel> downloadList = null;
        String query;
        query = "SELECT * FROM " + TABLE_PRODUCT_DATA + " WHERE " + PRODUCT_CATEGORY + " = \'" + category + "\'";
        Logger.debug("get data query : " + query);

        Cursor cursor = this.db.rawQuery(query, null);
        if (cursor != null && (cursor.getCount() > 0)) {

            downloadList = new ArrayList<>();

            while (cursor.moveToNext()) {

                ItemDataModel itemDataModel = new ItemDataModel();
                itemDataModel.setItemId(cursor.getString(cursor.getColumnIndex(PRODUCT_ID)));
                itemDataModel.setItemName(cursor.getString(cursor.getColumnIndex(PRODUCT_NAME)));
                itemDataModel.setPrice(cursor.getString(cursor.getColumnIndex(PRODUCT_PRICE)));
                itemDataModel.setDetails(cursor.getString(cursor.getColumnIndex(PRODUCT_DETAILS)));
                itemDataModel.setCartStatus(cursor.getString(cursor.getColumnIndex(CART_STATUS)));
                itemDataModel.setProductCategory(cursor.getString(cursor.getColumnIndex(PRODUCT_CATEGORY)));

                downloadList.add(itemDataModel);
            }
            cursor.close();
        }
        return downloadList;
    }

    public ArrayList<ItemDataModel> getCartsData() {

        ArrayList<ItemDataModel> downloadList = null;
        String query;
        query = "SELECT * FROM " + TABLE_PRODUCT_DATA + " WHERE " + CART_STATUS + " = \'" + "added" + "\'";
        Logger.debug("get carts data query : " + query);

        Cursor cursor = this.db.rawQuery(query, null);
        if (cursor != null && (cursor.getCount() > 0)) {

            downloadList = new ArrayList<>();

            while (cursor.moveToNext()) {

                ItemDataModel itemDataModel = new ItemDataModel();
                itemDataModel.setItemId(cursor.getString(cursor.getColumnIndex(PRODUCT_ID)));
                itemDataModel.setItemName(cursor.getString(cursor.getColumnIndex(PRODUCT_NAME)));
                itemDataModel.setPrice(cursor.getString(cursor.getColumnIndex(PRODUCT_PRICE)));
                itemDataModel.setDetails(cursor.getString(cursor.getColumnIndex(PRODUCT_DETAILS)));
                itemDataModel.setCartStatus(cursor.getString(cursor.getColumnIndex(CART_STATUS)));
                itemDataModel.setProductCategory(cursor.getString(cursor.getColumnIndex(PRODUCT_CATEGORY)));

                downloadList.add(itemDataModel);
            }
            cursor.close();
        }
        return downloadList;
    }

    public ItemDataModel getProductDetails(String productId) {

        ItemDataModel itemDataModel = new ItemDataModel();
        String query;
        query = "SELECT * FROM " + TABLE_PRODUCT_DATA + " WHERE " + PRODUCT_ID + " = \"" + productId + "\"";
        Logger.debug("get carts data query : " + query);

        Cursor cursor = this.db.rawQuery(query, null);
        if (cursor != null && (cursor.getCount() > 0)) {

            while (cursor.moveToNext()) {
                itemDataModel.setItemId(cursor.getString(cursor.getColumnIndex(PRODUCT_ID)));
                itemDataModel.setItemName(cursor.getString(cursor.getColumnIndex(PRODUCT_NAME)));
                itemDataModel.setPrice(cursor.getString(cursor.getColumnIndex(PRODUCT_PRICE)));
                itemDataModel.setDetails(cursor.getString(cursor.getColumnIndex(PRODUCT_DETAILS)));
                itemDataModel.setCartStatus(cursor.getString(cursor.getColumnIndex(CART_STATUS)));
                itemDataModel.setProductCategory(cursor.getString(cursor.getColumnIndex(PRODUCT_CATEGORY)));
            }
            cursor.close();
        }
        return itemDataModel;
    }


}
