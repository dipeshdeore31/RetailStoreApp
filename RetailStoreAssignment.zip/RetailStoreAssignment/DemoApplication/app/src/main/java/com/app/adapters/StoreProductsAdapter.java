package com.app.adapters;

import android.content.Context;
import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Filter;
import android.widget.ImageView;
import android.widget.TextView;

import com.app.demoapplication.R;
import com.app.models.ItemDataModel;

import java.util.ArrayList;

public class StoreProductsAdapter extends BaseAdapter {

    Context context;
    private ArrayList<ItemDataModel> itemsDataList;
    Typeface typefaceRegular;
    private ValueFilter valueFilter;
    private ArrayList<ItemDataModel> tempItemList;

    public StoreProductsAdapter(Context context, ArrayList<ItemDataModel> itemsList) {
        this.context = context;
        this.itemsDataList = itemsList;
        this.tempItemList = itemsList;
        typefaceRegular = Typeface.createFromAsset(context.getApplicationContext().getAssets(), "RobotoCondensedRegular.ttf");
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder viewHolder = new ViewHolder();
        View rowView = convertView;

        if (rowView == null) {
            LayoutInflater inflator = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            rowView = inflator.inflate(R.layout.item_product, null);

            viewHolder.txtItemName = (TextView) rowView.findViewById(R.id.txt_item_name);
            viewHolder.txtPrice = (TextView) rowView.findViewById(R.id.txt_price);
            viewHolder.imgItemPicture = (ImageView) rowView.findViewById(R.id.img_item_pic);

            viewHolder.txtItemName.setTypeface(typefaceRegular);
            viewHolder.txtPrice.setTypeface(typefaceRegular);

            rowView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }
        viewHolder.txtItemName.setText(itemsDataList.get(position).getItemName());
        viewHolder.txtPrice.setText(itemsDataList.get(position).getPrice());

        int imageResourceId = itemsDataList.get(position).getResourceId();

        viewHolder.imgItemPicture.setImageResource(imageResourceId);


        return rowView;
    }

    @Override
    public int getCount() {
        return itemsDataList.size();
    }

    @Override
    public Object getItem(int position) {
        return itemsDataList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }


    static class ViewHolder {
        protected TextView txtItemName;
        protected TextView txtPrice;
        protected ImageView imgItemPicture;
    }

    public Filter getFilter() {

        if (valueFilter == null) {

            valueFilter = new ValueFilter();
        }
        return valueFilter;
    }


    private class ValueFilter extends Filter {

        @Override
        protected FilterResults performFiltering(CharSequence constraint) {

            FilterResults results = new FilterResults();

            if (constraint != null && constraint.length() > 0) {

                ArrayList<ItemDataModel> filterList = new ArrayList<ItemDataModel>();

                for (int i = 0; i < tempItemList.size(); i++) {

                    String itemName = tempItemList.get(i).getItemName();

                    if (itemName.toUpperCase().contains(constraint.toString().trim().toUpperCase())) {

                        filterList.add(tempItemList.get(i));
                    }


                }
                results.count = filterList.size();

                results.values = filterList;

            } else {

                itemsDataList = tempItemList;

                results.count = itemsDataList.size();

                results.values = itemsDataList;

            }
            return results;
        }

        @SuppressWarnings("unchecked")
        @Override
        protected void publishResults(CharSequence constraint,
                                      FilterResults results) {
            itemsDataList = (ArrayList<ItemDataModel>) results.values;
            notifyDataSetChanged();
        }
    }


}
