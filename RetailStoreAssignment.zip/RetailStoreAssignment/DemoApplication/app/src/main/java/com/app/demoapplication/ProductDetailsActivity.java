package com.app.demoapplication;

import android.app.Activity;
import android.content.Context;
import android.database.sqlite.SQLiteException;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.app.adapters.StoreProductsAdapter;
import com.app.dao.DbHelper;
import com.app.dao.RetailStoreDao;
import com.app.models.ItemDataModel;
import com.app.utilities.AbstractActivity;
import com.app.utilities.UiUtils;

import java.util.ArrayList;

public class ProductDetailsActivity extends AbstractActivity {

    private TextView txtTitle;
    private Activity activity;
    private ImageButton ibtnAddToCart;
    private ImageView imgProduct;
    private TextView txtProductName;
    private TextView txtPrice;
    private TextView txtDetail;
    private String productId;
    private Integer imageId;

    private Bundle bundle = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_detail);
        activity = this;
        initUI();
        setFonts();
        setListener();
        setCustomData();
    }


    private void initUI() {

        txtTitle = (TextView) findViewById(R.id.txt_title);
        txtTitle.setText(getResources().getString(R.string.products));
        ibtnAddToCart = (ImageButton) findViewById(R.id.ibtn_cart);
        imgProduct = (ImageView) findViewById(R.id.img_product);
        txtProductName = (TextView) findViewById(R.id.txt_name);
        txtPrice = (TextView) findViewById(R.id.txt_price);
        txtDetail = (TextView) findViewById(R.id.txt_detail);

    }

    private void setCustomData() {

        bundle = getIntent().getExtras();
        if (bundle != null) {
            productId = bundle.getString(Product_ID);
            imageId = bundle.getInt(Image_ID);
        }

        ItemDataModel itemDataModel = new ItemDataModel();
        try {

            DbHelper.init(activity);

            RetailStoreDao retailStoreDao = new RetailStoreDao();

            itemDataModel = retailStoreDao.getProductDetails(productId);

        } catch (SQLiteException sqliteException) {

        } finally {

            DbHelper.sharedDbHelper().closeDatabase();

        }
        imgProduct.setImageResource(imageId);
        txtTitle.setText(itemDataModel.getProductCategory());
        txtProductName.setText(itemDataModel.getItemName());
        txtPrice.setText(itemDataModel.getPrice());
        txtDetail.setText(itemDataModel.getDetails());

    }

    private void setFonts() {

        txtTitle.setTypeface(regularFont);
        txtProductName.setTypeface(regularFont);
        txtPrice.setTypeface(regularFont);
        txtDetail.setTypeface(regularFont);

    }

    private void setListener() {
        ibtnAddToCart.setOnClickListener(new AddToCartListener());
    }

    private class AddToCartListener implements View.OnClickListener {

        @Override
        public void onClick(View view) {

            try {

                DbHelper.init(activity);

                RetailStoreDao retailStoreDao = new RetailStoreDao();

                retailStoreDao.updateCartStatus(productId,"added");

            } catch (SQLiteException sqliteException) {

            } finally {

                DbHelper.sharedDbHelper().closeDatabase();

            }

            Toast.makeText(activity, getResources().getString(R.string.item_added), Toast.LENGTH_SHORT).show();


        }
    }


}
