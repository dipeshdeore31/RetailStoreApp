CREATE  TABLE "products" ("product_id" TEXT,"product_name" TEXT, "product_price" TEXT, "product_details" TEXT,"cart_status" TEXT,"productCategory" TEXT);

INSERT INTO "products" VALUES('1','Morphy Richards','₹ 9999','20-Liter Solo Microwave', '','Electronics');
INSERT INTO "products" VALUES('2','LG 32LF550A','₹ 12499','HD Ready LED TV', 'added','Electronics');
INSERT INTO "products" VALUES('3','JT Mini USB Vaccum Cleaner','₹ 58499','for keyboard, mobile and camera', '','Electronics');

INSERT INTO "products" VALUES('4','Unique Gadget','₹ 8423','Foldable Wooden Study Table', 'added','Furniture');
INSERT INTO "products" VALUES('5','Hetal Chair','₹ 1456','Mesh metal medium black', '','Furniture');
INSERT INTO "products" VALUES('6','Almirah wardrobe cupboard','₹ 9229','Foldable cabinet', '','Furniture');
